exports.user = {
    host : 'localhost',
    user : 'root',
    password : '123456',
    database : 'knowit',
    charset: 'utf8mb4_unicode_ci'
};